package com.lassi.univents;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class EventAddedConfirmation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_added_confirmation);
    }
}
